#include "Motion.h"
#include "MotorDriver.h"
#include <Arduino.h>


Motion::Motion(MotorPins _left, MotorPins _right) {
  this->lm = new MotorDriver(_left);
  this->rm = new MotorDriver(_right);
}

// direction
void Motion::forward(uint8_t _speed) {
  this->lm->forward(_speed);
  this->rm->forward(_speed);
}
void Motion::backward(uint8_t _speed) {
  this->lm->backward(_speed);
  this->rm->backward(_speed);
}
void Motion::left(uint8_t _speed) {
  this->lm->backward(_speed);
  this->rm->forward(_speed);
}
void Motion::right(uint8_t _speed) {
  this->lm->forward(_speed);
  this->rm->backward(_speed);
}

// stop mode
void Motion::idle() {
  this->lm->idle();
  this->rm->idle();
}
void Motion::stop() {
  this->lm->stop();
  this->rm->stop();
}
