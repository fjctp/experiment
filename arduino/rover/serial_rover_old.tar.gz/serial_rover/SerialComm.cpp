#include "define.h"
#include "SerialComm.h"

#include <Arduino.h>

SerialComm::SerialComm(HardwareSerial *port, unsigned int bit_rate) : Comm() {
  this->_port=port;
  this->_port->begin(bit_rate);
  this->send_message("Comm started\n");
}

command_t SerialComm::get_command() {
  command_t cmd1;
  cmd1.code = COMMAND_CODE_ERROR;
  cmd1.parameter = 0;
  if(this->_port->available()>0) {
    char bf[COMMAND_BUFFER_LENGTH];
    this->_port->readBytesUntil(COMMAND_TERMINATE_CHAR,
                               bf,
                               COMMAND_BUFFER_LENGTH);
    cmd1 = this->prase_command(bf);
  }
  else {
    cmd1.code=COMMAND_CODE_WAIT;
    cmd1.parameter = 0;
  }
  //this->send_message("cmd: ");
  //this->send_message(&cmd1.code);
  //this->send_message(":");
  //char tmp[2];
  //itoa(cmd1.parameter, tmp, 10);
  //this->send_message(tmp);
  //this->send_message("\n");
  return cmd1;
}

void SerialComm::send_message(char *msg) {
    this->_port->print(msg);
}
