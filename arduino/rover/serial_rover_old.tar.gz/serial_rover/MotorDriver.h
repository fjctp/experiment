#ifndef MOTORDRIVER_H
#define MOTORDRIVER_H

#include <Arduino.h>

struct MotorPins {
  uint8_t en_pin;
  uint8_t fwd_pin;
  uint8_t bwd_pin;
};

/*
 * Motor Driver (Call by Motion Class)
 * Should be called by Motion class not directly
 */
class MotorDriver {

private:
  static const uint8_t MIN_SPD = 0;
  static const uint8_t MAX_SPD = 10;
  static const uint8_t MIN_PWM_VALUE = 0;
  static const uint8_t MAX_PWM_VALUE = 255;
  MotorPins pins;
  bool isEnabled;

  void _set_speed(uint8_t _pin, uint8_t _speed);
  void _enable();
  void _disable();

public:
  MotorDriver(MotorPins _pins); // initialize internal variables
                              // and put the motor into idle mode
  // direction
  void forward(uint8_t _speed);
  void backward(uint8_t _speed);

  // stop mode
  void idle(); // core spins freely
  void stop(); // stop the core from spinning

};

#endif
