#ifndef MOTION_H
#define MOTION_H

#include "MotorDriver.h"
#include <Arduino.h>

class Motion {

private:
  MotorDriver* lm;
  MotorDriver* rm;

public:
  Motion(MotorPins _left, MotorPins _right);

  // direction
  void forward(uint8_t _speed);
  void backward(uint8_t _speed);
  void left(uint8_t _speed);
  void right(uint8_t _speed);

  // stop mode
  void idle(); // core spins freely
  void stop(); // stop the core from spinning
};

#endif
