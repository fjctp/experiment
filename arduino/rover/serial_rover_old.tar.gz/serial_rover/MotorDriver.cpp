#include "MotorDriver.h"
#include <Arduino.h>

// private functions
void MotorDriver::_set_speed(uint8_t _pin, uint8_t _speed) {
  _speed = constrain(_speed, MIN_SPD, MAX_SPD);
  analogWrite(_pin, 
    map(_speed, MIN_SPD, MAX_SPD, MIN_PWM_VALUE, MAX_PWM_VALUE));
}
void MotorDriver::_enable() {
  if (this->isEnabled != true)
  {
    digitalWrite(this->pins.en_pin, HIGH);
    this->isEnabled = true;
  }
}
void MotorDriver::_disable() {
  if (this->isEnabled != false)
  {
    digitalWrite(this->pins.en_pin, LOW);
    this->isEnabled = false;
  }
}

MotorDriver::MotorDriver(MotorPins _pins) {
  this->pins = _pins;
  pinMode(this->pins.en_pin, OUTPUT);
  this->idle();
}
void MotorDriver::forward(uint8_t _speed) {
  this->_set_speed(this->pins.fwd_pin, _speed);
  this->_set_speed(this->pins.bwd_pin, this->MIN_SPD);
  this->_enable();
}
void MotorDriver::backward(uint8_t _speed) {
  this->_set_speed(this->pins.fwd_pin, this->MIN_SPD);
  this->_set_speed(this->pins.bwd_pin, _speed);
  this->_enable();
}

// stop mode
void MotorDriver::idle() {
  this->_set_speed(this->pins.fwd_pin, this->MIN_SPD);
  this->_set_speed(this->pins.bwd_pin, this->MIN_SPD);
  this->_disable();
}
/*
 * idle mode
 * to stop the motor, apply same voltage to both PWM pins
 */
void MotorDriver::stop() {
  this->_set_speed(this->pins.fwd_pin, this->MAX_SPD);
  this->_set_speed(this->pins.bwd_pin, this->MAX_SPD);
  this->_enable();
}
