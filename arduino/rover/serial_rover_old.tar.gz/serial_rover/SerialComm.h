#ifndef SERIALCOMM_H
#define SERIALCOMM_H

#include "define.h"
#include "Comm.h"
#include <Arduino.h>

#define SERIAL_SPEED_0 9600
#define SERIAL_SPEED_1 19200
#define SERIAL_SPEED_2 38400
#define SERIAL_SPEED_3 115200

class SerialComm : public Comm {

private:
  HardwareSerial *_port;

public:
  SerialComm(HardwareSerial *port, unsigned int bit_rate);
  
  // inherted
  command_t get_command();
  void send_message(char *msg);
};

#endif
